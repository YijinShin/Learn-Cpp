#pragma once
class CStage
{
public:
	CStage() {}
	virtual ~CStage() {}
};

