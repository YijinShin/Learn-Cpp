#pragma once
#include "Vector2.h"

typedef struct tagInfo
{
	float		fX;
	float		fY;
	float		fCX;
	float		fCY;
	Vector2		Dir;

}INFO;