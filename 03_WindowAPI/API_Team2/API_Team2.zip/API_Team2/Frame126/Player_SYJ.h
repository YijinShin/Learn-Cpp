#pragma once
#include "Player.h"

class CPlayer_SYJ: public CPlayer
{
};

