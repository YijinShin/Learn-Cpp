#pragma once

#define			WINCX		800
#define			WINCY		600

#define			PI			3.141592f
#define			PURE		= 0

#define			DEG2RAD		1.f / 180.f * PI
#define			RAD2DEG		1.f / PI * 180.f

#define			OBJ_NOEVENT  0
#define			OBJ_DEAD     1

extern		HWND	g_hWnd;