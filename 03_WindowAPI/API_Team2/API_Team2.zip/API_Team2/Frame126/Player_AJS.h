#pragma once
class Player_AJS
{
};

