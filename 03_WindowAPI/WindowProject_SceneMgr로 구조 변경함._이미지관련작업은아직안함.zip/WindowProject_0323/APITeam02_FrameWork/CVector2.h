#pragma once
class CVector2
{
public:
	float	x;
	float	y;

public:
	CVector2();
	~CVector2();

	void		Normalize();
};