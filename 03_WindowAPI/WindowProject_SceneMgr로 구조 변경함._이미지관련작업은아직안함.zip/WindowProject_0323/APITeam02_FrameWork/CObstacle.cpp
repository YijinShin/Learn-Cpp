#include "stdafx.h"
#include "CObstacle.h"

CObstacle::CObstacle()
{
}

CObstacle::~CObstacle()
{
}

void CObstacle::Initialize()
{
}

int CObstacle::Update()
{
    return 0;
}

void CObstacle::Late_Update()
{
}

void CObstacle::Render(HDC hDC)
{
}

void CObstacle::Release()
{
}
