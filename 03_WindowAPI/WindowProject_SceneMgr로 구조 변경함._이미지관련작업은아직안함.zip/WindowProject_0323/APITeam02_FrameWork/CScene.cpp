#include "stdafx.h"
#include "CScene.h"

CScene::CScene():m_eStageID(SC_STAGE_SYJ)
{
}

CScene::~CScene()
{
}
