#pragma once

enum STAGEID {
	STAGE_START,
	STAGE_AJS,
	STAGE_PIS,
	STAGE_SHH,
	STAGE_SYJ,
	STAGE_END
};

enum OBJID
{
	OBJ_MONSTER,
	OBJ_PLAYER,
	OBJ_BULLET,
	OBJ_MONSTERBULLET,
	OBJ_SHIELD,
	OBJ_OBSTACLE,
	OBJ_FLAG,			// ���� ���Ŀ� �߰�
	OBJ_END
};

enum LINEPOINTS { 
	LPOINT,
	RPOINT,
	END 
};

enum GAMEMODE {
	MODE_EDITOR,
	MODE_GAME
};

enum EDITORTOOL {
	TOOL_LPOINT,
	TOOL_RPOINT,
	TOOL_NOTOOL
};

// TODO : ���α׷��� �ʿ��� �ڵ带 �߰��ϼ���

enum SCENEID {
	SC_LOGO,
	SC_MENU,
	SC_EDIT,

	SC_STAGE_AJS,
	SC_STAGE_PIS,
	SC_STAGE_SHH,
	SC_STAGE_SYJ,

	SC_END
};